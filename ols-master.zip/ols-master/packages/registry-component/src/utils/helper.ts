export const getRandomStr = () => Math.random().toString().slice(2)
