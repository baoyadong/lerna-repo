import packageUtil from './utils/package'
import htmlUtil from './utils/html'
import configUtil from './utils/config'
import cssModulesUtil from './utils/cssModules'
import loadableUtil from './utils/loadable'

module.exports = async function migrationVite() {
  const workDir = process.cwd()
  /**
   * 1. 更新package.json
   * 2. 生成html
   * 3. 生成配置文件
   * 4. 更新css modules
   */
  await packageUtil(workDir)
  await htmlUtil(workDir)
  await configUtil(workDir)
  await cssModulesUtil(workDir)
  await loadableUtil(workDir)
}
