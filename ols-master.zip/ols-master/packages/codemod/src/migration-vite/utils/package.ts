import path from 'path'
import fs from 'fs'

export default async function packageUtil(workDir) {
  const packageDir = path.join(workDir, 'package.json')

  if (!fs.existsSync(packageDir)) {
    console.error('项目下不存在package.json')
    process.exit(0)
  }

  let packageData = { devDependencies: {}, scripts: {} }
  try {
    packageData = JSON.parse(fs.readFileSync(packageDir, { encoding: 'utf-8' }))
  } catch (error) {
    console.error(error)
    process.exit(0)
  }

  /**
   * 1. 删除@tuya-fe/ols
   * 2. 安装依赖@vitejs/plugin-react-refresh、less、vite、rollup-plugin-visualizer
   * 3. 更新scripts
   */
  const devDependencies: any = packageData.devDependencies || {}
  if (devDependencies['@tuya-fe/ols']) {
    delete devDependencies['@tuya-fe/ols']
  }
  devDependencies.vite = '^2.1.5'
  devDependencies['@vitejs/plugin-react-refresh'] = '^1.3.2'
  devDependencies.less = '^4.1.1'
  devDependencies['rollup-plugin-visualizer'] = '^5.3.0'
  packageData.devDependencies = devDependencies

  const scripts: any = packageData.scripts || {}
  Object.keys(scripts).forEach((scriptKey) => {
    if (scripts[scriptKey] && scripts[scriptKey].startsWith('ols')) {
      delete scripts[scriptKey]
    }
  })
  scripts.dev = 'vite'
  scripts.build = 'tsc && vite build'
  scripts.serve = '"vite preview'
  packageData.scripts = scripts

  fs.writeFileSync(packageDir, JSON.stringify(packageData, null, 2))
}
