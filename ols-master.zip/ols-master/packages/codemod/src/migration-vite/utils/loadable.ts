import fs from 'fs'
import path from 'path'
import * as walk from 'babylon-walk'
import generator from '@babel/generator'
import { getAst } from './util'

const firstUpperCase = (str) => str.replace(/^\S/, (s) => s.toUpperCase())

export default function loadable(workDir) {
  const filePath = path.join(workDir, 'src', 'routes.ts')
  const ast = getAst(filePath)
  const imports = []

  walk.recursive(ast, {
    ObjectProperty(node) {
      if (node.key.name === 'component' && node.value.type === 'ArrowFunctionExpression') {
        const calleeNode = node.value.body
        if (calleeNode.callee.type === 'Import' && calleeNode.arguments && calleeNode.arguments.length) {
          const importPath = calleeNode.arguments[0].value
          const variable = importPath.split('/').slice(1).map(firstUpperCase).join('')
          imports.push({
            importPath,
            variable,
          })
          node.value = {
            type: 'Identifier',
            name: variable,
          }
        }
      }
    },
  })

  let source = imports.map((item) => `import ${item.variable} from '${item.importPath}'\n`).join('')

  source += generator(ast).code

  fs.writeFileSync(filePath, source)
}
