import path from 'path'
import fs from 'fs'
import { getConfigOptions } from './util'

const getConfigContent = (options) => `import { defineConfig } from 'vite'
import reactRefresh from '@vitejs/plugin-react-refresh'
import visualizer from 'rollup-plugin-visualizer'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [reactRefresh()],
  resolve: {
    alias: [{ find: '@', replacement: path.resolve(__dirname, './src') }],
  },
  css: {
    preprocessorOptions: {
      less: {
        // 支持内联 JavaScript
        javascriptEnabled: true,
      },
    },
    modules: {},
  },
  build: {
    rollupOptions: {
      plugins: [visualizer()],
    },
  },
  define: ${options.define},
  server: {
    proxy: ${options.proxy},
  }
})
`

export default function(workDir) {
  const configContent = getConfigContent(getConfigOptions(workDir))

  fs.writeFileSync(path.join(workDir, 'vite.config.ts'), configContent)
}