import fs from 'fs'
import path from 'path'
import * as walk from 'babylon-walk'
import generator from '@babel/generator'
import glob from 'glob'
import { noSemicolon, readFileContent, getAst } from './util'

export default function (workDir) {
  const tsxFiles = glob.sync(path.join(workDir, 'src/**/**.tsx'))

  tsxFiles.forEach((file) => {
    let fileContent = readFileContent(file)
    const ast = getAst(file, fileContent)

    const importLess = []

    walk.recursive(ast, {
      ImportDeclaration(node) {
        if (
          node.specifiers &&
          node.specifiers.length > 0 &&
          node.source &&
          /.*\.less/.test(node.source.value) &&
          !/.*\.module\.less/.test(node.source.value)
        ) {
          const lessFilePath = path.join(path.dirname(file), node.source.value)
          // 1. 重命名
          if (fs.existsSync(lessFilePath)) {
            fs.renameSync(lessFilePath, lessFilePath.replace('.less', '.module.less'))
          }

          // 2. 更新import
          if (node.leadingComments) {
            delete node.leadingComments
          }
          const origin = noSemicolon(generator(node.source).code)
          importLess.push({ origin, now: origin.replace('.less', '.module.less') })
        }
        if (
          !(node.specifiers && node.specifiers.length > 0) &&
          node.source &&
          /antd\/lib.*/.test(node.source.value)
        ) {
          fileContent = fileContent.replace(node.source.value, node.source.value.replace('lib', 'es'))
        }
      },
    })

    // const fileContent = generator(ast).code
    fileContent = importLess.reduce((prev, item) => prev.replace(item.origin, item.now), fileContent)
    fs.writeFileSync(file, fileContent)
  })
}
