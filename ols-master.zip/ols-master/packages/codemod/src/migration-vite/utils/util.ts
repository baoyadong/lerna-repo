import fs from 'fs'
import path from 'path'
import * as babel from 'babel-core'
import * as walk from 'babylon-walk'
import generator from '@babel/generator'

export function readFileContent(filePath) {
  return fs.readFileSync(filePath, { encoding: 'utf-8' })
}

export function noSemicolon(str) {
  if (!str.endsWith(';')) {
    return str
  }

  return str.slice(0, -1)
}

export function getAst(filePath, source = '') {
  source = source || readFileContent(filePath)
  return babel.parse(source, {
    filename: path.basename(filePath),
    presets: [
      require.resolve('@babel/preset-env'),
      require.resolve('@babel/preset-typescript'),
      require.resolve('@babel/preset-react'),
    ],
    plugins: [require.resolve('babel-plugin-transform-class-properties')],
  })
}

export function getConfigOptions(workDir) {
  const olsConfigPath = path.join(workDir, '.ols.config.ts')
  const ast = getAst(olsConfigPath)

  const options = {
    define: '{}',
    proxy: '{}',
  }

  walk.recursive(ast, {
    ObjectProperty(node) {
      if (node.key && node.key.type === 'Identifier' && node.key.name === 'define') {
        const defineProperties = node.value.properties

        defineProperties.forEach((item, index) => {
          defineProperties[index].value.value = `'${defineProperties[index].value.value}'`
        })

        options.define = generator(node.value).code
      }
      if (node.key && node.key.type === 'Identifier' && node.key.name === 'devServer') {
        walk.recursive(node.value, {
          ObjectProperty(node) {
            if (node.key && node.key.type === 'Identifier' && node.key.name === 'proxy') {
              options.proxy = generator(node.value).code
            }
          },
        })
      }
    },
  })

  return options
}
