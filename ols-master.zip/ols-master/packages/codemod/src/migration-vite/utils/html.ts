import fs from 'fs'
import path from 'path'

const htmlContent = `<!DOCTYPE html>
<html>
  <head>
		<base href="/" />
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />

		<meta http-equiv="x-dns-prefetch-control" content="on" />
		<meta name="renderer" content="webkit" />
		<meta name="force-rendering" content="webkit" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="icon" type="image/svg+xml" href="//static1.tuyacn.com/static/ty-lib/favicon.ico" />
    <title>运营后台</title>
  </head>
  <body>
    <div id="app"></div>
    <script type="module" src="/src/index.tsx"></script>
  </body>
</html>`

export default function(workDir) {
  fs.writeFileSync(path.join(workDir, 'index.html'), htmlContent)

  const indexHtml = path.join(workDir, 'src', 'index.html')
  if (fs.existsSync(indexHtml)) {
    fs.unlinkSync(indexHtml)
  }
}