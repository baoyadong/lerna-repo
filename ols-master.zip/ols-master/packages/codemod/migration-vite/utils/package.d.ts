export default function packageUtil(workDir: any): Promise<void>;
