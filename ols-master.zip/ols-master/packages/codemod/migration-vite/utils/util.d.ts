export declare function readFileContent(filePath: any): string;
export declare function noSemicolon(str: any): any;
export declare function getAst(filePath: any, source?: string): any;
export declare function getConfigOptions(workDir: any): {
    define: string;
    proxy: string;
};
