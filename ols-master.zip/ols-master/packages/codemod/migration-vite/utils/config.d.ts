export default function (workDir: any): void;
