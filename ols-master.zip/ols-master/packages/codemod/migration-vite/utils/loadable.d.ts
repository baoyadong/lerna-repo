export default function loadable(workDir: any): void;
