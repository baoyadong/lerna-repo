module.exports = {
  type: "component"
}
