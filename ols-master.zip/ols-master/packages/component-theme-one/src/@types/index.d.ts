declare module '*.less' {
  const resource: { readonly [key: string]: string }
  export default resource
}
