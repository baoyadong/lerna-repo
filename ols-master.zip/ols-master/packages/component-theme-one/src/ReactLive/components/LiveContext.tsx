import { createContext } from 'react'

const LiveContext = createContext({})

export default LiveContext
