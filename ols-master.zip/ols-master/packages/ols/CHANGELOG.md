## [1.0.1](https://registry.code.tuya-inc.top/ols/ols/compare/1.0.0...1.0.1) (2021-11-02)


### Bug Fixes

* 组件发布成功后再生成changelog ([2c579a5](https://registry.code.tuya-inc.top/ols/ols/commits/2c579a56c3674305a7f36bfdf1a9df8c3c9d847c))
* eslint修复 ([5646439](https://registry.code.tuya-inc.top/ols/ols/commits/5646439841369e017001e9c18ed708b898b82253))
* mars默认支持按需 ([96bdf25](https://registry.code.tuya-inc.top/ols/ols/commits/96bdf252bc0f68dd20c49bbef14edd872b48de6a))


### Features

* 支持自定义命令行&支持快捷logger ([fd74883](https://registry.code.tuya-inc.top/ols/ols/commits/fd74883d92397913e73d02516db7984d132cd202))



# [1.0.0](https://registry.code.tuya-inc.top/ols/ols/compare/0.1.3...1.0.0) (2021-10-08)


### Bug Fixes

* 关闭experimentalUseImportModule（使用webpack内置type打包资源时报错） ([5ac0c11](https://registry.code.tuya-inc.top/ols/ols/commits/5ac0c11e42541d2dfbc2513a7c81e4b0141aede2))
* 兼容libra接口更新 ([b1f51f1](https://registry.code.tuya-inc.top/ols/ols/commits/b1f51f16cdef1225c723bb12a2a305b194d0ad84))
* 修复本地资源打包的路径问题 ([0c13284](https://registry.code.tuya-inc.top/ols/ols/commits/0c13284b378779ff925935a59c8326971fbc2c1c))
* 修复babel-plugin-import重复引问题&升级doc插件版本 ([24cc989](https://registry.code.tuya-inc.top/ols/ols/commits/24cc98996439906ef94ea0e7131473ca5fa690a5))
* 移除ts-loader & hard-source-webpack-plugin ([d495771](https://registry.code.tuya-inc.top/ols/ols/commits/d49577180796530b18a328aa6888d39f6c97b187))
* babelLoader开启cacheDirectory ([07e4b06](https://registry.code.tuya-inc.top/ols/ols/commits/07e4b063eff8f8fbf25b6966833d3c509537b6e0))
* corejs usage ([c4a601b](https://registry.code.tuya-inc.top/ols/ols/commits/c4a601b38bd8ba9baf1835dd6462c935fd4ad50c))
* cssModules支持驼峰 ([1321137](https://registry.code.tuya-inc.top/ols/ols/commits/1321137549342164e7be811468b4bb9866534974))
* index.html打包的时候关闭压缩 ([04411d3](https://registry.code.tuya-inc.top/ols/ols/commits/04411d3e1698820fd33d814f4dfd65103ec85afd))
* webpack5下target改成['web', 'es5'] ([1102ab9](https://registry.code.tuya-inc.top/ols/ols/commits/1102ab940d0b745d1717432bf367dc80e7b7f30e))


### Features

* 添加@babel/plugin-transform-runtime ([690f1d5](https://registry.code.tuya-inc.top/ols/ols/commits/690f1d503d7fb44799b26aed58bf89cda907291a))
* 项目打包和组件打包corejs引入方式区分 ([87fb50f](https://registry.code.tuya-inc.top/ols/ols/commits/87fb50f7cdab6fc85b3ccf71b2aef1ca3c46f99d))
* 证书生成策略修改 ([8fff8e1](https://registry.code.tuya-inc.top/ols/ols/commits/8fff8e19a0594b5bea0617486e94a8814a69bf9e))
* 支持sass编译 ([3e09893](https://registry.code.tuya-inc.top/ols/ols/commits/3e09893c358d216f369189cda0d501ad861ffe02))
* babel配置更新&升级ols-plugin-component-docs@1.0.0-alpha.5 ([51f9362](https://registry.code.tuya-inc.top/ols/ols/commits/51f93624e4407dd433b60d334a6ec8293dbd961b))
* Dll支持可配置 ([d1da05c](https://registry.code.tuya-inc.top/ols/ols/commits/d1da05c8110066b786e777154c6dab4f5286f055))



## [0.1.3](https://registry.code.tuya-inc.top/ols/ols/compare/0.1.2...0.1.3) (2021-04-16)


### Bug Fixes

* react-refresh/babel可配置 ([e7a6b4f](https://registry.code.tuya-inc.top/ols/ols/commits/e7a6b4fad37b6f3fe83118d6086adb03e02f54f7))



## [0.1.2](https://registry.code.tuya-inc.top/ols/ols/compare/0.1.0...0.1.2) (2021-04-16)


### Bug Fixes

* ols.config不是必要 ([7fdfe34](https://registry.code.tuya-inc.top/ols/ols/commits/7fdfe3447521be480fbe1a2fe01698d137800efc))


### Features

* react-refresh可配置 ([837c78c](https://registry.code.tuya-inc.top/ols/ols/commits/837c78c80032a07bdf03a90c36fa3acd8dfdd1ae))



# [0.1.0](https://registry.code.tuya-inc.top/ols/ols/compare/0.0.10...0.1.0) (2021-04-13)



## [0.0.10](https://registry.code.tuya-inc.top/ols/ols/compare/0.0.9...0.0.10) (2021-04-13)


### Features

* 删除编译时的assert输出 ([4f0fb34](https://registry.code.tuya-inc.top/ols/ols/commits/4f0fb347ba756e15e32611dc504794bab11d22f8))
* 添加react-refresh ([2e4cd72](https://registry.code.tuya-inc.top/ols/ols/commits/2e4cd7225067c3455050985d4e8a5f6cbfd31b25))



## [0.0.9](https://registry.code.tuya-inc.top/ols/ols/compare/0.0.7...0.0.9) (2021-04-13)


### Bug Fixes

* 修复config重复merge问题 ([024d401](https://registry.code.tuya-inc.top/ols/ols/commits/024d4018d05d15473181b6c8c162e089fffe571b))


### Features

* 添加webpackBar&dll ([4d1eddd](https://registry.code.tuya-inc.top/ols/ols/commits/4d1eddd439eefe65127c6351f0b42d2951bc9619))
* webpack构建信息不显示warning ([cf2f823](https://registry.code.tuya-inc.top/ols/ols/commits/cf2f823bd5cdc1578946b8dfbc8642b78c76a47e))



## [0.0.7](https://registry.code.tuya-inc.top/ols/ols/compare/0.0.6...0.0.7) (2021-01-25)



## [0.0.6](https://registry.code.tuya-inc.top/ols/ols/compare/0.0.5...0.0.6) (2021-01-14)


### Features

* 升级ty命令 ([4b8338b](https://registry.code.tuya-inc.top/ols/ols/commits/4b8338bc8e366c0e4963245d3574332ae574eb24))
* 支持模板可插拔 ([e3a918c](https://registry.code.tuya-inc.top/ols/ols/commits/e3a918c767134eb196c75ae9b3f53d2d7daa538f))



## [0.0.5](https://registry.code.tuya-inc.top/ols/ols/compare/0.0.4...0.0.5) (2021-01-13)


### Bug Fixes

* commandArgs去除默认9000端口 ([586cdd3](https://registry.code.tuya-inc.top/ols/ols/commits/586cdd300c680d393f8bedb1cd9ae6479240f24e))
* warning error ([46ceaa7](https://registry.code.tuya-inc.top/ols/ols/commits/46ceaa78248083795f112dcb0cfee5774d08138d))


### Features

* 下线预发和线上的发布功能 ([cb0c49b](https://registry.code.tuya-inc.top/ols/ols/commits/cb0c49b6ec40766c6d44e5f58bd31fe1b26e0cfb))
* 项目接入发布系统 ([1b526d0](https://registry.code.tuya-inc.top/ols/ols/commits/1b526d005f2cb9d951c3e3871c1fe66c038d866e))
* 支持发布清单处理 ([cb27377](https://registry.code.tuya-inc.top/ols/ols/commits/cb27377b94888865330bf2099a2e319629dc1d5b))



## [0.0.4](https://registry.code.tuya-inc.top/ols/ols/compare/e5ae7bd0b16646afb47941436dd02bf4f4fd2f17...0.0.4) (2021-01-06)


### Bug Fixes

* init不集成webpackConfig ([6114752](https://registry.code.tuya-inc.top/ols/ols/commits/61147528fa2c0df5abe14a484593b90b22e1b89e))
* MiniCssExtractPlugin conflict ([f3e1dee](https://registry.code.tuya-inc.top/ols/ols/commits/f3e1deebc8f708e73e7e8ee0bcd99f8a55376d3f))


### Features

* 插件添加名称 ([8412116](https://registry.code.tuya-inc.top/ols/ols/commits/8412116a02c9270f42fa142eebf3b81e61efa3c5))
* 处理webpack配置生成时机 ([66bdeae](https://registry.code.tuya-inc.top/ols/ols/commits/66bdeaecf60df25196493dbe3bbd3544e31f0e42))
* 覆盖率配置 ([6656937](https://registry.code.tuya-inc.top/ols/ols/commits/665693767d1868720066ac6a57a966b7bfc716b2))
* 兼容webpack&babel配置 ([cdda2f6](https://registry.code.tuya-inc.top/ols/ols/commits/cdda2f63119317c90d6f3ec1bf746cff26b9f4ea))
* 入口暴露program ([e8ca51e](https://registry.code.tuya-inc.top/ols/ols/commits/e8ca51e802438b53d53d847adfccc859a1876d34))
* 添加CHANGELOG ([8ced7e5](https://registry.code.tuya-inc.top/ols/ols/commits/8ced7e53fee76581ecaba9c8b6a43a562b97549c))
* 添加define ([4a90676](https://registry.code.tuya-inc.top/ols/ols/commits/4a906761addce6d45fdc7c7fc5e3e42db706cc13))
* 完善基础功能 ([e5ae7bd](https://registry.code.tuya-inc.top/ols/ols/commits/e5ae7bd0b16646afb47941436dd02bf4f4fd2f17))
* 支持单测 ([3f975ce](https://registry.code.tuya-inc.top/ols/ols/commits/3f975ceb4c6339796fd912b63ed0cad54735681e))
* 支持ty ([2209533](https://registry.code.tuya-inc.top/ols/ols/commits/22095334d4260a299ecc20de98f6d8734594230e))
* 自动识别用户引入方式区分css module ([78e3c0c](https://registry.code.tuya-inc.top/ols/ols/commits/78e3c0c71e9d6369739682d15c3807045a54e9f6))
* default import antd-component style ([1c3394b](https://registry.code.tuya-inc.top/ols/ols/commits/1c3394b6b56db65bd91989de22756c8a4d7924fa))
* dev过程中子进程出错，父进程退出 ([6432867](https://registry.code.tuya-inc.top/ols/ols/commits/6432867c86f745b1b5fbdda1524a98643b5beec5))
* dev下开启子进程，监听配置文件变更进行重启 ([d1b0504](https://registry.code.tuya-inc.top/ols/ols/commits/d1b050452f754636ce0a6a83a3281fa13fb160dc))
* gitlab project id changed ([e78f38d](https://registry.code.tuya-inc.top/ols/ols/commits/e78f38d0c9608956f924901a02a1bdc20f0d1523))
* Plugin透出更多信息 ([be4b1b9](https://registry.code.tuya-inc.top/ols/ols/commits/be4b1b9666506ef846d443e04667b15b598ca7f4))



