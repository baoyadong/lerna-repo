import defaultRegistry from '@tuya-fe/ols-registry-default'

enum ContainerType {
  Project = 'project',
  Component = 'component',
}

export function getRegistry(type: ContainerType) {
  if (!type) {
    return defaultRegistry
  }

  try {
    const typeRegistry = require(`@tuya-fe/ols-registry-${type}`)
    return [defaultRegistry, typeRegistry]
  } catch (error) {
    console.log(error)
    return defaultRegistry
  }
}
