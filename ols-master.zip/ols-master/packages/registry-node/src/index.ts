import dev from './commands/dev'
import build from './commands/build'
import deploy from './commands/deploy'

module.exports = {
  commands: [dev, build, deploy],
}
