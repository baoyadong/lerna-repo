declare const _default: {
    name: string;
    test: RegExp;
    process({ code }: {
        code: any;
    }): Promise<unknown>;
};
export default _default;
