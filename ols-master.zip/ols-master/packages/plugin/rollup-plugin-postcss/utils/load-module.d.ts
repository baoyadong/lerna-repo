export declare function loadModule(moduleId: any): any;
