declare const _default: (path: any) => any;
export default _default;
