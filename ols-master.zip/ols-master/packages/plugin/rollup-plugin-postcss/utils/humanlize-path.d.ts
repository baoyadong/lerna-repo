declare const humanlizePath: (filepath: any) => any;
export default humanlizePath;
