/**
 * 监听.ols.config配置文件变更，重启应用
 */
export {};
