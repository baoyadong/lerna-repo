export default function resolveDefine(opts: {
    define: any;
}): {
    'process.env': {};
};
