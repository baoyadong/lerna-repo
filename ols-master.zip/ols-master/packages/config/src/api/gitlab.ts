import axios from 'axios'
import download from 'download'
// import Helios from '@tuya-fe/helios'
import logger from '@tuya-fe/ols-util/logger'
import spinner from '@tuya-fe/ols-util/spinner'

const GITLAB_PROJECT_DOMAIN = 'https://registry.code.tuya-inc.top/api/v4/projects/12169'

const gitlabRequest = axios.create({
  baseURL: GITLAB_PROJECT_DOMAIN,
  timeout: 20 * 1000,
  headers: {
    'Content-Type': 'application/json',
  },
})

/**
 * 获取gitlab token
 *
 * @export
 * @return {*}
 */
export async function getPrivateToken() {
  const Helios = require('@tuya-fe/helios').default
  const mgr = new Helios({
    serverHost: 'http://in-mousika-config.wgine-dev.com:8181', // dev
    appid: 'frontend_developer-tools',
    clusterName: 'default',
    namespaceNames: ['application'],
  })

  try {
    const { result, success }: any = await mgr.get({
      cache: false,
      namespaces: ['application'],
      encrypted: false,
    })

    if (!success) {
      throw Error('获取token失败')
    }

    return result.application.olsGitlabToken
  } catch (error) {
    logger.error('获取token失败')
    process.exit(1)
  }
}

/**
 * 获取最后一次commit
 *
 * @export
 * @return {*}
 */
export async function getLastCommit() {
  spinner.start('正在检测模板更新')
  const privateToken = await getPrivateToken()
  return gitlabRequest('/repository/commits', {
    headers: { 'PRIVATE-TOKEN': privateToken },
  })
    .then((res) => {
      const commits = res.data || []
      return commits && commits.length ? commits[0].id : ''
    })
    .finally(() => {
      spinner.clear()
    })
}

/**
 * 下载模板文件
 *
 * @export
 * @return {*}
 */
export async function getGitlabRepository(homeDir) {
  spinner.start('正在从远端拉取模板')
  const privateToken = await getPrivateToken()
  return download(`${GITLAB_PROJECT_DOMAIN}/repository/archive`, homeDir, {
    extract: true,
    retries: 0,
    timeout: 10000,
    headers: { 'PRIVATE-TOKEN': privateToken },
  })
    .then((repository) => {
      spinner.clear()
      logger.success('模板拉取成功')
      return repository
    })
    .catch(() => {
      spinner.clear()
    })
}

/**
 * 获取模板列表
 *
 * @export
 * @return {*}
 */
export async function getTemplateList() {
  spinner.start('正在获取模板列表')
  const privateToken = await getPrivateToken()
  return axios('/repository/files/ols.json/raw?ref=master', {
    headers: { 'PRIVATE-TOKEN': privateToken },
  })
    .then((res) => {
      return res.data || []
    })
    .finally(() => {
      spinner.clear()
    })
}
