import os from 'os'
import fs from 'fs'
import axios from 'axios'
import qs from 'qs'
import path from 'path'
import logger from '@tuya-fe/ols-util/logger'

export const LOGIN_HOST = 'https://login-cn.tuya-inc.top:7799'

const AUTH_PATH = path.join(os.homedir(), '.ols', 'auth.json')

/**
 * 获取用户登录信息
 *
 * @export
 * @return {*}
 */
export function getAuth() {
  let auth
  try {
    auth = JSON.parse(fs.readFileSync(AUTH_PATH, 'utf-8')) || {}
  } catch (e) {
    auth = {}
  }

  return auth
}

/**
 * 更新用户登录信息
 *
 * @export
 * @param {*} [newAuth={}]
 */
export function setAuth(newAuth = {}) {
  // 更新缓存文件信息
  const auth = getAuth()
  fs.writeFileSync(AUTH_PATH, JSON.stringify({ ...auth, ...newAuth }, null, '  '))
}

/**
 * 登录
 *
 * @export
 * @param {*} [answer={}]
 */
export async function login(answer: any = {}) {
  const { data } = await axios({
    url: `${LOGIN_HOST}/login`,
    method: 'post',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    data: qs.stringify(answer),
  })

  if (!data.success) {
    logger.error('登录失败，请检查异常')
    process.exit(1)
  }

  const { token } = data.result
  setAuth({
    cookies: {
      SSO_USER_TOKEN: token,
    },
    username: answer.username,
  })
  // syncLogin({ SSO_USER_TOKEN: token });
}
