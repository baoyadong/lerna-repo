import axios from 'axios'
import path from 'path'
import logger from '@tuya-fe/ols-util/logger'
import spinner from '@tuya-fe/ols-util/spinner'
import git from '@tuya-fe/ols-util/git'
import { getAuth } from './login'

const DEPLOY_HOST = 'https://libra.tuya-inc.top:7799'

const libraRequest = axios.create({
  baseURL: DEPLOY_HOST,
  timeout: 20 * 1000,
  withCredentials: true,
  transformRequest: [
    function transformRequest(data, headers) {
      const { cookies = {} } = getAuth()
      headers.Cookie = Object.entries(cookies)
        .map(([name, value]) => `${name}=${value}`)
        .join('; ')
      return JSON.stringify(data)
    },
  ],
  headers: {
    'Content-Type': 'application/json',
  },
})

libraRequest.interceptors.response.use(
  (response) => {
    const isObj = typeof response.data === 'object'
    if (isObj) {
      return response
    }
    return Promise.reject(response)
  },
  (error) => {
    return Promise.reject(error)
  },
)

export default libraRequest

/**
 * 获取用户拥有的所有项目
 *
 * @export
 * @return {*}
 */
export function getProjectList() {
  return libraRequest({
    url: '/v1/project/getAll',
    method: 'get',
  })
}

export async function getRepo() {
  const remoteUrl = await git.listRemote(['--get-url']) // 当前项目仓库地址
  const repo = await getProjectDetail(remoteUrl) // 获取项目详情

  if (!repo) {
    const projectNames = getProjectNames(remoteUrl)
    logger.error(`${projectNames[0]} 没有找到项目, 请在发布系统 新建项目`)
    process.exit(0)
  }

  return repo
}

/**
 * 检测是否登录（通过判断cookie是否失效）
 *
 * @export
 * @return {*}
 */
export function checkIsLogin() {
  return new Promise((resolve) => {
    getProjectList()
      .then(() => {
        resolve(true)
      })
      .catch(() => {
        resolve(false)
      })
  })
}

/**
 * 获取发布区域
 *
 * @export
 * @return {*}
 */
export async function getRegionList() {
  spinner.start('正在获取发布区域')
  const result = await libraRequest({
    url: '/v1/region/getAll',
    method: 'get',
  })
    .then(({ data = {} }) => {
      const res = (data.data || []).map((item) => ({
        id: item.id,
        value: item.name,
        name: `${item.name}（${item.describe}）`,
      }))
      return res
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 获取远端分支
 *
 * @export
 * @return {*}
 */
export async function getRemoteBranch() {
  spinner.start('正在获取远端分支')
  const result = await libraRequest({
    url: '/v1/gitlab/branch/getAll',
    method: 'post',
  })
    .then(({ data = {} }) => {
      const res = data.data || []
      return (res || []).map((item) => ({
        name: item.name,
        value: item.commit.id,
      }))
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 通过gitUrl获取项目名
 *
 * @export
 * @param {string} repoUrl
 * @return {*}
 */
export function getRepoName(repoUrl: string) {
  const repoName = repoUrl.slice(0, -4).split('/').slice(-1)

  return repoName
}

/**
 * 获取项目名
 *
 * @export
 * @param {string} repoUrl
 * @return {string}
 */
export function getProjectNames(repoUrl: string) {
  const projectNames = [getRepoName(repoUrl), path.basename(path.resolve(process.cwd()))]

  try {
    const pkg = require(path.resolve(process.cwd(), 'package.json'))
    pkg && pkg.name && projectNames.unshift(pkg.name)
  } catch (error) {
    console.log(error)
  }

  return projectNames
}

/**
 * 查询项目详情
 *
 * @export
 * @param {string} repoUrl
 * @return {*}  {Promise<any>}
 */
export async function getProjectDetail(repoUrl: string): Promise<any> {
  const projectNames = getProjectNames(repoUrl)

  spinner.start('正在获取项目详情')
  let projects
  try {
    projects = (await getProjectList()).data.data || []
  } catch (error) {
    projects = []
  }
  spinner.clear()

  const repoList = projects
    .filter((item) => item.name && projectNames.includes(item.name))
    .map((item) => ({ ...item, id: Number(item.id) }))

  return repoList && repoList.length ? repoList[0] : null
}

/**
 * 获取项目所有的分支
 *
 * @export
 * @param {*} projectId
 * @return {*}
 */
export async function getProjectBranchs(projectId) {
  spinner.start('正在获取分支列表')
  const result = await libraRequest({
    url: '/v1/gitlab/branch/getAll',
    method: 'post',
    data: { projectId },
  })
    .then(({ data = {} }) => {
      const res = (data.data || []).map((item) => item.name)
      return res
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 获取项目某个分支的commits
 *
 * @export
 * @param {*} { projectId, branch }
 * @return {*}
 */
export async function getProjectCommits({ projectId, branch }) {
  spinner.start('正在获取commit列表')
  const result = await libraRequest({
    url: '/v1/gitlab/commit/getAll',
    method: 'post',
    data: { projectId, branch },
  })
    .then(({ data = {} }) => {
      const res = (data.data || []).map((item) => ({
        name: `${item.short_id}：${item.title}（${item.author_name}）`,
        value: item,
      }))
      return res
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 获取项目版本
 *
 * @export
 * @param {*} projectId
 * @return {*}
 */
export async function getProjectVersion(projectId) {
  spinner.start('正在获取项目版本')
  const result = await libraRequest({
    url: '/v1/version/get',
    method: 'post',
    data: { projectId },
  })
    .then(({ data = {} }) => {
      return data.build || ''
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 创建发布单
 *
 * @export
 * @param {*} data
 * @return {*}
 */
export async function createDeploy(params) {
  spinner.start('正在创建发布单')
  const result = await libraRequest({
    url: '/v1/droneMission/insert',
    method: 'post',
    data: params,
  })
    .then(({ data = {} }) => {
      return (data.missions || []).find((item) => item.version === params.version) || {}
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 获取发布列表
 *
 * @export
 * @param {*} { env, projectId }
 * @return {*}
 */
export async function getDeployList({ env, projectId }) {
  spinner.start('正在获取发布单列表')
  const result = await libraRequest({
    url: '/v1/mission/getAll',
    method: 'post',
    data: {
      offset: 0,
      limit: 20, // 默认只取前20条
      filterOptions: { env },
      projectId,
    },
  })
    .then(({ data = {} }) => {
      return data.missions || []
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 获取发布单详情
 *
 * @export
 * @param {*} orderId
 * @return {*}
 */
export async function getDeployDetail(orderId) {
  spinner.start('正在获取发布单详情')
  const result = await libraRequest({
    url: '/v1/mission/get',
    method: 'post',
    data: {
      id: orderId,
    },
  })
    .then(({ data = {} }) => {
      return data.mission || {}
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 获取发布单流程信息
 *
 * @export
 * @param {*} { orderId, env, projectId, version }
 * @return {*}
 */
export async function getFlowDetail({ orderId, env, projectId, version }) {
  spinner.start('正在获取发布状态')
  const result = await libraRequest({
    url: '/v1/flow/getAll',
    method: 'post',
    data: {
      env,
      projectId,
      version,
    },
  })
    .then(({ data = {} }) => {
      const flow = (data.flows || []).find((item) => item.missionId === orderId) || {}
      return flow
    })
    .finally(() => {
      spinner.clear()
    })
  return result
}

/**
 * 执行发布
 *
 * @export
 * @param {*} id
 * @return {*}
 */
export async function execDeploy(id) {
  spinner.start('正在提交发布')
  const result = await libraRequest({
    url: '/v1/drone/run',
    method: 'post',
    data: {
      flowId: id,
    },
  }).finally(() => {
    spinner.clear()
  })
  return result
}

/**
 * 获取build详情
 *
 * @export
 * @param {*} id
 * @return {*}
 */
export async function getBuildDetail({ buildId, repo }) {
  const result = await libraRequest({
    url: `/drone-server/api/repos/${repo}/builds/${buildId}`,
    method: 'get',
  }).then(({ data = {} }) => {
    return data.stages || []
  })
  return result
}
