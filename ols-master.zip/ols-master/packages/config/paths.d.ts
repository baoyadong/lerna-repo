declare const _default: {
    appDist: string;
    appHtml: string;
    appIndexJs: string;
    appSrc: string;
    appNodeModules: string;
    assets: string;
    appPkg: string;
};
export default _default;
