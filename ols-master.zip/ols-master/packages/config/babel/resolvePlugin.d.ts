export default function resolvePlugin(plugins: any): any;
