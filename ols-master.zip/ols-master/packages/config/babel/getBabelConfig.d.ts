export default function getBabelConfig(isEnvDevelopment?: boolean): {
    presets: any;
    plugins: any;
    cacheDirectory: boolean;
};
