export declare const CONFIG_FILES: string[];
export declare function getExistFile({ cwd, files }: {
    cwd: any;
    files: any;
}): string;
export default function getJestConfigPath(ctx: any): string;
