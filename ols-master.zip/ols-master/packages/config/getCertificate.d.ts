export default function getCertificate(homeDir: any): Promise<unknown>;
