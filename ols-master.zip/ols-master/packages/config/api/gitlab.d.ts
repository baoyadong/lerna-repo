/// <reference types="node" />
/**
 * 获取gitlab token
 *
 * @export
 * @return {*}
 */
export declare function getPrivateToken(): Promise<any>;
/**
 * 获取最后一次commit
 *
 * @export
 * @return {*}
 */
export declare function getLastCommit(): Promise<any>;
/**
 * 下载模板文件
 *
 * @export
 * @return {*}
 */
export declare function getGitlabRepository(homeDir: any): Promise<void | Buffer>;
/**
 * 获取模板列表
 *
 * @export
 * @return {*}
 */
export declare function getTemplateList(): Promise<any>;
