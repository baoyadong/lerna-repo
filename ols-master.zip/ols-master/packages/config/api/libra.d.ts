declare const libraRequest: import("axios").AxiosInstance;
export default libraRequest;
/**
 * 获取用户拥有的所有项目
 *
 * @export
 * @return {*}
 */
export declare function getProjectList(): import("axios").AxiosPromise<any>;
export declare function getRepo(): Promise<any>;
/**
 * 检测是否登录（通过判断cookie是否失效）
 *
 * @export
 * @return {*}
 */
export declare function checkIsLogin(): Promise<unknown>;
/**
 * 获取发布区域
 *
 * @export
 * @return {*}
 */
export declare function getRegionList(): Promise<any>;
/**
 * 获取远端分支
 *
 * @export
 * @return {*}
 */
export declare function getRemoteBranch(): Promise<any>;
/**
 * 通过gitUrl获取项目名
 *
 * @export
 * @param {string} repoUrl
 * @return {*}
 */
export declare function getRepoName(repoUrl: string): string[];
/**
 * 获取项目名
 *
 * @export
 * @param {string} repoUrl
 * @return {string}
 */
export declare function getProjectNames(repoUrl: string): (string | string[])[];
/**
 * 查询项目详情
 *
 * @export
 * @param {string} repoUrl
 * @return {*}  {Promise<any>}
 */
export declare function getProjectDetail(repoUrl: string): Promise<any>;
/**
 * 获取项目所有的分支
 *
 * @export
 * @param {*} projectId
 * @return {*}
 */
export declare function getProjectBranchs(projectId: any): Promise<any>;
/**
 * 获取项目某个分支的commits
 *
 * @export
 * @param {*} { projectId, branch }
 * @return {*}
 */
export declare function getProjectCommits({ projectId, branch }: {
    projectId: any;
    branch: any;
}): Promise<any>;
/**
 * 获取项目版本
 *
 * @export
 * @param {*} projectId
 * @return {*}
 */
export declare function getProjectVersion(projectId: any): Promise<any>;
/**
 * 创建发布单
 *
 * @export
 * @param {*} data
 * @return {*}
 */
export declare function createDeploy(params: any): Promise<any>;
/**
 * 获取发布列表
 *
 * @export
 * @param {*} { env, projectId }
 * @return {*}
 */
export declare function getDeployList({ env, projectId }: {
    env: any;
    projectId: any;
}): Promise<any>;
/**
 * 获取发布单详情
 *
 * @export
 * @param {*} orderId
 * @return {*}
 */
export declare function getDeployDetail(orderId: any): Promise<any>;
/**
 * 获取发布单流程信息
 *
 * @export
 * @param {*} { orderId, env, projectId, version }
 * @return {*}
 */
export declare function getFlowDetail({ orderId, env, projectId, version }: {
    orderId: any;
    env: any;
    projectId: any;
    version: any;
}): Promise<any>;
/**
 * 执行发布
 *
 * @export
 * @param {*} id
 * @return {*}
 */
export declare function execDeploy(id: any): Promise<import("axios").AxiosResponse<any, any>>;
/**
 * 获取build详情
 *
 * @export
 * @param {*} id
 * @return {*}
 */
export declare function getBuildDetail({ buildId, repo }: {
    buildId: any;
    repo: any;
}): Promise<any>;
