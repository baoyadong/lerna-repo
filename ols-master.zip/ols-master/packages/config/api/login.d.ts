export declare const LOGIN_HOST = "https://login-cn.tuya-inc.top:7799";
/**
 * 获取用户登录信息
 *
 * @export
 * @return {*}
 */
export declare function getAuth(): any;
/**
 * 更新用户登录信息
 *
 * @export
 * @param {*} [newAuth={}]
 */
export declare function setAuth(newAuth?: {}): void;
/**
 * 登录
 *
 * @export
 * @param {*} [answer={}]
 */
export declare function login(answer?: any): Promise<void>;
