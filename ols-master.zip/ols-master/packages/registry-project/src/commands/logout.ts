import logger from '@tuya-fe/ols-util/logger'
import { setAuth } from '@tuya-fe/ols-config/api/login'

export default {
  registry: 'logout',
  expand: (program) => {
    program.description('用户退出')
  },
  action: () => {
    // 退出登录只要把用户信息抹除就好了
    setAuth({
      cookies: {},
    })

    logger.success('退出成功')
  },
}
