import inquirer from 'inquirer'
import spinner from '@tuya-fe/ols-util/spinner'
import logger from '@tuya-fe/ols-util/logger'
import { checkIsLogin } from '@tuya-fe/ols-config/api/libra'
import { getAuth, login } from '@tuya-fe/ols-config/api/login'

export default {
  registry: 'login',
  expand: (program) => {
    program.description('用户登录')
  },
  action: async () => {
    const auth = getAuth()

    // 1. 检测是否已经登录过
    spinner.start('正在检查登录状态')
    const isLogin = await checkIsLogin()
    spinner.clear()

    // 2. 已登录
    if (isLogin) {
      logger.success(
        `当前已有用户登录，账号为：${logger.chalk.green(
          auth.username,
        )}\n如需退出登录，请执行${logger.chalk.green(' ols logout ')}`,
      )
      return
    }

    // 3. 未登录，引导用户登录
    const answer = await inquirer.prompt([
      {
        type: 'input',
        name: 'username', // 不知道为啥登录系统硬要把userNo叫成userNo
        message: '请输入员工工号',
        default() {
          return auth.username || ''
        },
      },
      {
        type: 'password',
        name: 'password',
        message: '请输入涂鸦小智密码',
      },
      {
        type: 'input',
        name: 'dynamicPassword',
        message: '请输入涂鸦小智动态口令',
      },
    ])
    spinner.start('正在登录')
    await login(answer)
    spinner.clear()
    logger.success('登录成功')
  },
}
