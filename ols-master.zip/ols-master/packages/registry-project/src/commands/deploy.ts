import inquirer from 'inquirer'
import pick from 'lodash/pick'
import spinner from '@tuya-fe/ols-util/spinner'
import logger from '@tuya-fe/ols-util/logger'
import git, { checkAndCommitRepo, getBranch } from '@tuya-fe/ols-util/git'
import { getFormatEllipsis, getFullDay } from '@tuya-fe/ols-util/helper'
import {
  getRepo,
  checkIsLogin,
  getRegionList,
  getProjectBranchs,
  getProjectCommits,
  getProjectVersion,
  createDeploy,
  getDeployList,
  getDeployDetail,
  getFlowDetail,
  getBuildDetail,
  execDeploy,
} from '@tuya-fe/ols-config/api/libra'
import { loggerArr, loggerDeployTable, loggerBuilds } from '../helper'

export default {
  registry: 'deploy',
  expand: (program) => {
    program
      .description('发布系统')
      .option('-o, --order <orderId>', '查看发布单详情')
      .option('-l, --list', '查看全部发布单（最近20条）')
  },
  action: async (ctx) => {
    // 1. 先判断是否登录
    spinner.start('正在检查登录状态')
    const isLogin = await checkIsLogin()
    spinner.clear()

    // 2. 未登录直接退出
    if (!isLogin) {
      logger.warning(`请先执行 ${logger.chalk.green('ols login')} 进行登录`)
      process.exit(1)
    }

    const { list, order } = ctx.commandArgs
    // 查看发布列表
    if (list) {
      showList()
      return
    }

    // 查看发布单详情
    if (order) {
      showDetail(order)
      return
    }

    // 发布
    deploy()
  },
}

// 查看发布列表
export async function showList() {
  const repo = await getRepo() // 获取项目详情
  const answer = await inquirer.prompt([
    {
      type: 'list',
      name: 'env',
      message: '选择发布环境',
      choices: [
        {
          name: '日常环境',
          value: 'daily',
        },
        {
          name: '预发环境',
          value: 'pre',
        },
        {
          name: '线上环境',
          value: 'prod',
        },
      ],
    },
  ])
  const deployList = await getDeployList({
    env: answer.env,
    projectId: repo.id,
  })
  loggerDeployTable(
    deployList.map((item) => {
      // 'ID', '分支', '创建时间', '发布说明', 'commit', '版本'
      const { id, branch, createdAt, describe, commit, version, user } = item
      return [
        id,
        getFormatEllipsis(branch, 18),
        getFullDay(createdAt * 1000),
        getFormatEllipsis(describe, 21),
        commit.slice(0, 8),
        version,
        user.name,
      ]
    }),
  )
}

// 查看发布单详情
export async function showDetail(orderId) {
  const answer = await inquirer.prompt([
    {
      type: 'list',
      name: 'env',
      message: '选择发布环境',
      choices: [
        {
          name: '日常环境',
          value: 'daily',
        },
        {
          name: '预发环境',
          value: 'pre',
        },
        {
          name: '线上环境',
          value: 'prod',
        },
      ],
    },
  ])
  const detail = await getDeployDetail(orderId)
  const flow = await getFlowDetail({
    orderId,
    env: answer.env,
    projectId: detail.projectId,
    version: detail.version,
  })
  spinner.start('正在获取构建状态')
  const builds: any[] = await Promise.all(
    flow.buildIds.map((item) =>
      getBuildDetail({
        buildId: item,
        repo: flow.repo,
      }),
    ),
  )
  spinner.clear()
  const strArr = [
    { label: '发布ID', value: detail.id },
    { label: '发布分支', value: detail.branch },
    { label: '发布项目', value: `${detail.project.name}（${detail.project.displayName}）` },
    { label: '发布描述', value: detail.describe.replace('\n', '') },
    { label: 'commit', value: detail.commit },
    { label: '创建人', value: `${detail.user.name}（${detail.user.email}）` },
    { label: '创建时间', value: getFullDay(detail.createdAt * 1000) },
    { label: '发布版本', value: detail.version },
    { label: '发布方式', value: `${detail.deployTypeInfo.nameZh}（${detail.deployTypeInfo.describe}）` },
    { label: '发布环境', value: answer.env },
    { label: '发布状态', value: flow.statusZh },
    { label: '发布详情', value: '' },
  ]
  strArr.forEach((item) => {
    loggerArr([{ label: `${item.label}  ` }, { label: item.value, color: 'cyan' }])
  })
  loggerBuilds(builds)
}

// 发布
export async function deploy() {
  // 1. 检测是否提交了代码，最好要保证本地目录干净
  const isCheckRepo = await checkAndCommitRepo()
  if (!isCheckRepo) {
    return
  }

  // 2. 获取用户选择的信息
  await git.fetch('--all') // 同步远程分支
  const { current } = await getBranch() // 当前分支
  const repo = await getRepo() // 获取项目详情

  const answer = await inquirer.prompt([
    {
      type: 'list',
      name: 'env',
      message: '选择发布环境',
      choices: [
        {
          name: '日常环境',
          value: 'daily',
        },
        // {
        //   name: '预发环境',
        //   value: 'pre',
        // },
        // {
        //   name: '线上环境',
        //   value: 'prod',
        // },
      ],
    },
    {
      type: 'checkbox',
      name: 'region',
      message: '选择发布区域',
      choices: async (ans) => {
        const regionList = await getRegionList()
        const dailyRegionList = regionList.filter((x) => x.value === 'tx')

        return ans.env === 'daily' ? dailyRegionList : regionList
      },
      default(ans) {
        return ans.env === 'daily' ? ['tx'] : []
      },
      validate(value: string) {
        if (!value.length) {
          return '请选择部署区域'
        }
        return true
      },
    },
    {
      type: 'list',
      name: 'branch',
      loop: false,
      message: '请选择发布的分支',
      choices: async () => {
        const branchs = await getProjectBranchs(repo.id)
        return branchs
      },
      default: current,
    },
    {
      type: 'list',
      name: 'commit',
      loop: false,
      message: '请选择commit',
      choices: async (ans) => {
        const { branch } = ans
        const commits = await getProjectCommits({ projectId: repo.id, branch })
        return commits.slice(0, 20) // 暂时只取20个
      },
    },
    {
      type: 'input',
      name: 'version',
      message: '请输入version',
      default: async () => {
        const version = await getProjectVersion(repo.id)
        return `v0.0.0.${version}`
      },
      validate(value: string) {
        if (!value.length) {
          return '请输入version'
        }
        return true
      },
    },
    {
      type: 'input',
      name: 'describe',
      message: '请输入发布描述',
      default(ans) {
        return ans.commit.title || ''
      },
      validate(value: string) {
        if (!(value && value.length)) {
          return '请输入发布描述'
        }
        return true
      },
    },
    {
      type: 'list',
      name: 'deployType',
      message: '请选择发布方式',
      default: '1',
      choices: [
        { name: '正常流程', value: '1' },
        { name: '金丝雀发布', value: '3' },
      ],
    },
    {
      when: (ans) => ans.deployType === '3',
      type: 'input',
      name: 'canaryTag',
      message: '请输入灰度tag',
      default: (ans) => {
        return ans.branch.split('/').reverse()[0]
      },
      validate(value: string) {
        if (!value.length) {
          return '请输入灰度tag'
        }
        return true
      },
    },
    {
      when: (ans) => ans.deployType === '3',
      type: 'input',
      name: 'gatewayVersion',
      message: '请输入网关版本',
    },
    {
      when: (ans) => ans.deployType === '3',
      type: 'input',
      name: 'envTag',
      message: '请输入云端tag',
    },
  ])

  // 3. 创建发布单
  let deployDetail: any = {}
  try {
    deployDetail = await createDeploy({
      ...pick(answer, [
        'branch',
        'deployType',
        'describe',
        'env',
        'projectId',
        'region',
        'version',
        'canaryTag',
      ]),
      commit: answer.commit.id,
      deployType: Number(answer.deployType),
      projectId: repo.id,
      routeConfig:
        answer.deployType === '3'
          ? JSON.stringify({
              version: answer.gatewayVersion || '',
              envtag: answer.envTag || '',
            })
          : '',
    })
  } catch (error) {
    logger.warning(`当前版本 ${answer.version} 已存在发布单！`)
    process.exit(1)
  }

  // 4. 执行发布
  const flow = await getFlowDetail({
    orderId: deployDetail.id,
    env: answer.env,
    projectId: deployDetail.projectId,
    version: deployDetail.version,
  })
  try {
    await execDeploy(flow.id)
  } catch (error) {
    logger.error('提交发布失败')
    process.exit(0)
  }
  logger.success(`提交发布成功，如需查看发布单详情，请执行 ols deploy --order ${deployDetail.id}`)
}
