export declare function pickPropertyByArr(arr: any[], key: string): any[];
export declare const getDays: () => string;
export declare const getFullDay: (timestamp: any) => string;
export declare function getFormatEllipsis(str: any, len: any): any;
export declare function getTimes(time: number): string;
