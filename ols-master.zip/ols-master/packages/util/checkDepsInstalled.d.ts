export default function checkDepsInstalled(projectDirectory: any): boolean;
