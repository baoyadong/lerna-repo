export default function processNodeEnv(command: any): void;
