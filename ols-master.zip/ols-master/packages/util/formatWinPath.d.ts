export default function formatWinPath(outputPath: any): any;
