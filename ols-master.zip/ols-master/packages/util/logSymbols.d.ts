declare const logSymbols: {
    info: string;
    success: string;
    warning: string;
    error: string;
};
export default logSymbols;
